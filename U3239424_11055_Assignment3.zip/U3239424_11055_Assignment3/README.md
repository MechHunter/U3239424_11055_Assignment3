# Assignment Notes  

## Use the map to get some basic statistics of each of Australia's major cities.  

The map is a cool concept and it works well. However, it lacks functionality and displays little information.  

I don't think the layout is very intuitive, the page does not flow nicely. I tried a few different things with this assignment, however I was not entirely sure how to piece them all together resulting in this problem.  

# Resources used  

https://www.freepik.com/free-vector/background-realistic-abstract-technology-particle_6938839.htm  

https://australiamap360.com/australia-blank-map  